import { Save, Search, UserRound, UsersRound, X } from 'lucide-react'
import { PageHeader } from '@/components/ui/page-header'
import { Card } from '@/components/ui/card'
import { Button, ButtonLink } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { EmptyState } from '@/components/data/empty-state'
import { getPermittedCarteiras } from '@/utils/auth/get-permitted-carteiras'
import { listCarteirasForSelect, listCondominiosForSelect } from '@/features/cadastros/queries'
import { createResponsavelUnidade, updateResponsavelUnidade } from '@/features/responsaveis-unidades/actions'
import {
  hasResponsavelUnidadeFilters,
  listResponsaveisUnidades,
  normalizeResponsavelUnidadeFilters,
} from '@/features/responsaveis-unidades/queries'

type ResponsaveisPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>
}

function getParam(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value
}

export default async function ResponsaveisPage({ searchParams }: ResponsaveisPageProps) {
  const params = await searchParams
  const scope = await getPermittedCarteiras()

  const filters = normalizeResponsavelUnidadeFilters({
    search: getParam(params?.q),
    carteiraId: getParam(params?.carteira_id),
    condominioId: getParam(params?.condominio_id),
    contato: getParam(params?.contato),
    ativo: getParam(params?.ativo),
  })

  const [rows, carteiras, condominios] = await Promise.all([
    listResponsaveisUnidades(scope, filters),
    listCarteirasForSelect(scope),
    listCondominiosForSelect(scope),
  ])

  const filtrosAtivos = hasResponsavelUnidadeFilters(filters)
  const ativos = rows.filter((row: any) => row.ativo !== false).length
  const semTelefone = rows.filter((row: any) => !row.telefone).length
  const semEmail = rows.filter((row: any) => !row.email).length

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Base Cadastral"
        title="Responsáveis"
        description="Cadastro de apoio usado para preencher responsável, documento, telefone e e-mail nas importações de inadimplência."
      />

      <section className="grid gap-3 md:grid-cols-3">
        <Card className="relative overflow-hidden p-5">
          <div className="absolute right-4 top-4 rounded-2xl bg-[var(--gkli-primary-light)] p-2 text-[var(--gkli-primary)]">
            <UsersRound size={18} />
          </div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">Ativos</p>
          <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">{ativos}</p>
          <p className="mt-1 text-sm text-slate-500">responsáveis no resultado</p>
        </Card>

        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">Sem telefone</p>
          <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">{semTelefone}</p>
          <p className="mt-1 text-sm text-slate-500">precisam de saneamento</p>
        </Card>

        <Card className="p-5">
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">Sem e-mail</p>
          <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">{semEmail}</p>
          <p className="mt-1 text-sm text-slate-500">cadastro incompleto</p>
        </Card>
      </section>

      <Card className="p-5">
        <div className="mb-4 flex items-start gap-3">
          <div className="rounded-2xl bg-slate-100 p-2 text-slate-500">
            <UserRound size={18} />
          </div>
          <div>
            <h2 className="text-base font-medium text-slate-950">Novo responsável de apoio</h2>
            <p className="mt-1 text-sm text-slate-500">Informe condomínio, unidade e contatos que devem ser reutilizados nas próximas importações.</p>
          </div>
        </div>

        <form action={createResponsavelUnidade} className="grid gap-3 xl:grid-cols-[minmax(180px,.75fr)_minmax(220px,1fr)_110px_110px_minmax(190px,1fr)_140px_150px_minmax(180px,1fr)_auto] xl:items-end">
          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Carteira</span>
            <Select name="carteira_id" required defaultValue={filters.carteiraId ?? ''}>
              <option value="">Selecione</option>
              {carteiras.map((carteira: any) => (
                <option key={carteira.id} value={carteira.id}>
                  {carteira.nome}
                </option>
              ))}
            </Select>
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Condomínio</span>
            <Select name="condominio_id" required defaultValue={filters.condominioId ?? ''}>
              <option value="">Selecione</option>
              {condominios.map((condominio: any) => (
                <option key={condominio.id} value={condominio.id}>
                  {condominio.nome}
                </option>
              ))}
            </Select>
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Bloco</span>
            <Input name="bloco" />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Unidade</span>
            <Input name="unidade" required />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Responsável</span>
            <Input name="responsavel_nome" />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Documento</span>
            <Input name="responsavel_documento" />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Telefone</span>
            <Input name="telefone" />
          </label>

          <label className="space-y-1.5">
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">E-mail</span>
            <Input name="email" type="email" />
          </label>

          <Button type="submit">
            <Save size={16} />
            Salvar
          </Button>
        </form>
      </Card>

      <Card className="overflow-hidden p-0">
        <div className="border-b border-slate-100 px-5 py-4">
          <div className="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
            <div>
              <h2 className="text-base font-medium text-slate-950">Base de responsáveis</h2>
              <p className="mt-1 text-sm text-slate-500">Edite contatos de apoio sem alterar diretamente a unidade operacional.</p>
            </div>

            {filtrosAtivos ? (
              <ButtonLink href="/app/responsaveis" variant="secondary" size="sm">
                <X size={15} />
                Limpar filtros
              </ButtonLink>
            ) : null}
          </div>

          <form className="mt-4 grid gap-3 xl:grid-cols-[minmax(240px,1.3fr)_minmax(180px,.85fr)_minmax(220px,1fr)_150px_170px_auto] xl:items-end">
            <label className="space-y-1.5">
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Busca</span>
              <div className="relative">
                <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <Input
                  name="q"
                  className="pl-9"
                  placeholder="Unidade, bloco, responsável, CPF/CNPJ, telefone ou e-mail"
                  defaultValue={filters.search ?? ''}
                />
              </div>
            </label>

            <label className="space-y-1.5">
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Carteira</span>
              <Select name="carteira_id" defaultValue={filters.carteiraId ?? ''}>
                <option value="">Todas</option>
                {carteiras.map((carteira: any) => (
                  <option key={carteira.id} value={carteira.id}>
                    {carteira.nome}
                  </option>
                ))}
              </Select>
            </label>

            <label className="space-y-1.5">
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Condomínio</span>
              <Select name="condominio_id" defaultValue={filters.condominioId ?? ''}>
                <option value="">Todos</option>
                {condominios.map((condominio: any) => (
                  <option key={condominio.id} value={condominio.id}>
                    {condominio.nome}
                  </option>
                ))}
              </Select>
            </label>

            <label className="space-y-1.5">
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Status</span>
              <Select name="ativo" defaultValue={filters.ativo ?? ''}>
                <option value="">Todos</option>
                <option value="ativo">Ativos</option>
                <option value="inativo">Inativos</option>
              </Select>
            </label>

            <label className="space-y-1.5">
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Contato</span>
              <Select name="contato" defaultValue={filters.contato ?? ''}>
                <option value="">Todos</option>
                <option value="sem_telefone">Sem telefone</option>
                <option value="sem_email">Sem e-mail</option>
                <option value="incompleto">Cadastro incompleto</option>
              </Select>
            </label>

            <Button type="submit">Filtrar</Button>
          </form>
        </div>

        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState
              title="Nenhum responsável encontrado"
              description="Ajuste os filtros ou cadastre um responsável de apoio para enriquecer futuras importações."
            />
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {rows.map((row: any) => (
              <form
                key={row.id}
                action={updateResponsavelUnidade}
                className="grid gap-3 px-5 py-4 transition hover:bg-slate-50 xl:grid-cols-[minmax(230px,1.1fr)_90px_90px_minmax(180px,1fr)_140px_150px_minmax(180px,1fr)_120px_150px] xl:items-end"
              >
                <input type="hidden" name="id" value={row.id} />

                <div className="min-w-0 xl:self-center">
                  <p className="truncate text-sm font-medium text-slate-950">{row.condominios?.nome ?? '-'}</p>
                  <p className="mt-1 truncate text-xs text-slate-500">
                    {row.carteiras?.nome ?? '-'} · origem {row.origem ?? '-'}
                  </p>
                </div>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Bloco</span>
                  <Input name="bloco" defaultValue={row.bloco ?? ''} />
                </label>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Unidade</span>
                  <Input name="unidade" required defaultValue={row.unidade ?? ''} />
                </label>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Responsável</span>
                  <Input name="responsavel_nome" defaultValue={row.responsavel_nome ?? ''} />
                </label>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Documento</span>
                  <Input name="responsavel_documento" defaultValue={row.responsavel_documento ?? ''} />
                </label>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Telefone</span>
                  <Input name="telefone" defaultValue={row.telefone ?? ''} />
                </label>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">E-mail</span>
                  <Input name="email" type="email" defaultValue={row.email ?? ''} />
                </label>

                <label className="space-y-1.5">
                  <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">Status</span>
                  <span className="flex h-10 items-center gap-2">
                    <input
                      type="checkbox"
                      name="ativo"
                      defaultChecked={row.ativo !== false}
                      className="size-4 rounded border-slate-300"
                    />
                    <Badge tone={row.ativo !== false ? 'green' : 'slate'}>{row.ativo !== false ? 'Ativo' : 'Inativo'}</Badge>
                  </span>
                </label>

                <div className="space-y-2">
                  <Textarea
                    name="observacoes"
                    defaultValue={row.observacoes ?? ''}
                    placeholder="Observações"
                    className="min-h-10 py-2"
                  />
                  <Button type="submit" size="sm" className="w-full">
                    <Save size={15} />
                    Salvar
                  </Button>
                </div>
              </form>
            ))}
          </div>
        )}
      </Card>
    </div>
  )
}
