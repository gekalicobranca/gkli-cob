export type Status = string
